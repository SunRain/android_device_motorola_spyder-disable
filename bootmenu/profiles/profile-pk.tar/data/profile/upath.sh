export PATH=/osh/usr/local/sbin:/osh/usr/local/bin:/osh/usr/sbin:/osh/usr/bin:/osh/sbin:/osh/bin
export DISPLAY=:0
export LD_LIBRARY_PATH=/usr/lib:/usr/local/lib
