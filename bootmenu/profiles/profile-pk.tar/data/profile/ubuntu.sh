#!/system/bin/sh
/usr/local/bin/ubuntu1.sh &
